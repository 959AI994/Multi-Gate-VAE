import deepgate
import torch
import torch.nn.functional as F

# 创建 DeepGate 模型并加载预训练模型
model = deepgate.Model()
model.load_pretrained()
model.eval()
# 创建 AigParser 并解析 AIG 文件
parser = deepgate.AigParser()
graph = parser.read_aiger('/home/whn/Hybrid-CEC/benchmarks/ec_instances/ec_m1.aiger')

hs, hf = model(graph)

print(hs.shape, hf.shape)

print(hf)
print(hf[1260])

tensor1 = hf[281]
tensor2 = hf[562]

# 计算余弦相似度
cosine_similarity = F.cosine_similarity(tensor1, tensor2, dim=0)
print("Cosine Similarity between node 281 and node 562:", cosine_similarity.item())